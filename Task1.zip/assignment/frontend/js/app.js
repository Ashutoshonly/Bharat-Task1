// frontend/js/app.js

document.addEventListener("DOMContentLoaded", () => {
  const registrationForm = document.getElementById("register-form");
  const loginForm = document.getElementById("login-form");
  const logoutSection = document.getElementById("logout-section");
  const logoutButton = document.getElementById("logout-btn");

  registrationForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const username = document.getElementById("register-username").value;
    const password = document.getElementById("register-password").value;

    try {
      const response = await fetch("http://localhost:3000/auth/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username, password }),
      });

      const data = await response.json();

      if (response.ok) {
        console.log(data.message);
      } else {
        console.error(data.message);
      }
    } catch (error) {
      console.error("Error during registration:", error);
    }
  });

  loginForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const username = document.getElementById("login-username").value;
    const password = document.getElementById("login-password").value;

    try {
      const response = await fetch("http://localhost:3000/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username, password }),
      });

      const data = await response.json();

      if (response.ok) {
        console.log(data.message);
        showLogoutSection();
      } else {
        console.error(data.message);
      }
    } catch (error) {
      console.error("Error during login:", error);
    }
  });

  logoutButton.addEventListener("click", async () => {
    try {
      const response = await fetch("http://localhost:3000/auth/logout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });

      const data = await response.json();

      if (response.ok) {
        console.log(data.message);
        hideLogoutSection();
      } else {
        console.error(data.message);
      }
    } catch (error) {
      console.error("Error during logout:", error);
    }
  });

  function showLogoutSection() {
    registrationForm.reset();
    loginForm.reset();
    logoutSection.style.display = "block";
  }

  function hideLogoutSection() {
    logoutSection.style.display = "none";
  }
});
