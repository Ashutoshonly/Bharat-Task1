// server.js

const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const config = require("./config");
const authRoute = require("./routes/authRoutes");

const app = express();
const port = config.port;

app.use(cors());
app.use(express.json());

// Connect to MongoDB Atlas
mongoose.connect(config.mongoURI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Routes
app.use("/auth", authRoute);

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
