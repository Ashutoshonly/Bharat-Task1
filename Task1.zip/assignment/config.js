module.exports = {
  mongoURI: "mongodb+srv://zeenat:zeenat@firstcluster.gxsun.mongodb.net/?retryWrites=true&w=majority",
  jwtSecret: "zeenat-assignment-1",
  port: 3000,
};
